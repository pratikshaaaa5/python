# Sample dictionaries
dict1 = {'a': 1, 'b': 2, 'c': 3}
dict2 = {'d': 4, 'e': 5, 'f': 6}

# 1. Check whether a given key exists in a dictionary or not.
key_to_check = 'a'
print(f"Key '{key_to_check}' exists in dict1:", key_to_check in dict1)

# 2. Iterate over dictionary items using for loop.
print("Iterating over dictionary items:")
for key, value in dict1.items():
    print(f"Key: {key}, Value: {value}")

# 3. Concatenate two dictionaries to create one.
concatenated_dict = {**dict1, **dict2}
print("Concatenated dictionary:", concatenated_dict)

# 4. Sum all the values of a dictionary.
sum_values = sum(dict1.values())
print("Sum of all values in dict1:", sum_values)

# 5. Get the maximum and minimum value of dictionary.
max_value = max(dict1.values())
min_value = min(dict1.values())
print("Maximum value in dict1:", max_value)
print("Minimum value in dict1:", min_value)
