import math
# Printing first 10 natural numbers
print("First 10 natural numbers:")
for i in range(1, 11):
    print(i)

# 2. First 10 even numbers in reverse order
print("First 10 even numbers in reverse order:", list(range(20, 0, -2)))

# 3. Table of a number accepted from user
num = int(input("Enter a number to print its table: "))
print(f"Table of {num}: {[num * i for i in range(1, 11)]}")


# 4. First 10 prime numbers
def is_prime(n):
    if n <= 1:
        return False
    for i in range(2, int(math.sqrt(n)) + 1):
        if n % i == 0:
            return False
    return True

prime_numbers = [num for num in range(2, 30) if is_prime(num)]
print("First 10 prime numbers:", prime_numbers[:10])

# 5. Sum of digits of numbers from 101 to 130
sum_of_digits = sum(int(digit) for number in range(101, 131) for digit in str(number))
print("Sum of digits of numbers from 101 to 130:", sum_of_digits)


