# Function to calculate the square of a number
def square_number(num):
    return num ** 2
