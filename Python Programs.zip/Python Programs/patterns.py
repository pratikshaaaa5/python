# Function to print right-angled triangle with digits
def print_right_angle_triangle():
    num = 1
    for i in range(1, 6):  # Number of rows
        for j in range(1, i + 1):  # Number of columns
            print(num, end=" ")
            num += 1

        print()  # Move to next line

# Calling the function
print_right_angle_triangle()

# Function to print a normal triangle of stars
def print_normal_triangle(lines):
    for i in range(1, lines + 1):
        print("*" * i)

# Calling the function with 5 lines
print_normal_triangle(5)

# Function to print a normal triangle of stars
def print_normal_triangle(lines):
    for i in range(1, lines + 1):
        print("*" * i)

# Calling the function with 5 lines
print_normal_triangle(5)

def generate_pascals_triangle(rows):
    triangle = []
    for i in range(rows):
        row = [1]  # First element of each row is always 1
        if triangle:
            last_row = triangle[-1]  # Get the previous row
            # Calculate the current row using the previous row
            row.extend([sum(pair) for pair in zip(last_row, last_row[1:])])
            row.append(1)  # Last element of each row is always 1
        triangle.append(row)
    return triangle

def print_pascals_triangle(triangle):
    for row in triangle:
        print(" ".join(map(str, row)).center(len(triangle[-1]) * 2))

# Generate and print Pascal's triangle with 6 rows
triangle = generate_pascals_triangle(6)
print_pascals_triangle(triangle)
