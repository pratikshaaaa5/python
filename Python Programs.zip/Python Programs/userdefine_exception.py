# Define a custom exception class
class CustomException(Exception):
    def __init__(self, message="This is a custom exception!"):
        self.message = message
        super().__init__(self.message)

# Function to check if a number is positive
def check_positive_number(num):
    if num <= 0:
        raise CustomException("Number must be positive")

# Test the function with user input
try:
    num = int(input("Enter a positive number: "))
    check_positive_number(num)
    print("Number is positive")
except CustomException as ce:
    print("Error:", ce)
