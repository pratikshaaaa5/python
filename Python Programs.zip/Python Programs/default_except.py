try:
    # Division by zero
    result = 10 / 0
except ZeroDivisionError:
    print("Error: Division by zero!")
except:
    print("An error occurred")
