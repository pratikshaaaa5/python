# SyntaxError
try:
    eval('print("Hello, world!"')
except SyntaxError:
    print("SyntaxError occurred")

# TypeError
try:
    sum = 10 + "5"
except TypeError:
    print("TypeError occurred")

# IndexError
try:
    lst = [1, 2, 3]
    print(lst[3])
except IndexError:
    print("IndexError occurred")

# ValueError
try:
    num = int("abc")
except ValueError:
    print("ValueError occurred")

# ZeroDivisionError
try:
    result = 10 / 0
except ZeroDivisionError:
    print("ZeroDivisionError occurred")

# FileNotFoundError
try:
    file = open("nonexistent_file.txt", "r")
except FileNotFoundError:
    print("FileNotFoundError occurred")
