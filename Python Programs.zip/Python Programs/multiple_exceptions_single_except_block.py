try:
    # Division by zero
    result = 10 / 0
except (ZeroDivisionError, ValueError):
    print("Error: Division by zero or invalid value!")
except:
    print("An error occurred")
