def count_words(file_content):
    return len(file_content.split())

def count_characters(file_content):
    return len(file_content)

def count_vowels(file_content):
    vowels = "aeiouAEIOU"
    return sum(1 for char in file_content if char in vowels)

def count_lines(file_content):
    return file_content.count('\n') + 1

def reverse_words(file_content):
    words = file_content.split()
    reversed_words = [word[::-1] for word in words]
    return ' '.join(reversed_words)

# Read the contents of the file
with open("sample.txt", "r") as file:
    content = file.read()

# Display number of words
print("Number of words:", count_words(content))

# Display number of characters
print("Number of characters:", count_characters(content))

# Display number of vowels
print("Number of vowels:", count_vowels(content))

# Display number of lines
print("Number of lines:", count_lines(content))

# Reverse each word and display it
print("Reversed words:", reverse_words(content))
