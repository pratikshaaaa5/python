import math
import random
import datetime

# Accessing built-in functions from the math module
print("Factorial of 5:", math.factorial(5))
print("Square root of 16:", math.sqrt(16))
print("Value of pi:", math.pi)

# Accessing built-in functions from the random module
print("Random number between 1 and 10:", random.randint(1, 10))
print("Random choice from a list:", random.choice(['apple', 'banana', 'orange']))

# Accessing built-in functions from the datetime module
current_time = datetime.datetime.now()
print("Current date and time:", current_time)
print("Formatted date:", current_time.strftime("%Y-%m-%d"))
