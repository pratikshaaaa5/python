# Importing functions from module1 and module2
from module1 import greet_user
from module2 import square_number

# Accessing functions from module1 and module2
greet_user("Alice")
result = square_number(5)
print("Square of 5 is:", result)
