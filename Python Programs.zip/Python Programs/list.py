sample_list = [1, 2, 3, 4, 5, 2, 3, -1, -2, -3, 0]

# 1. Sum all the items in a list.
print("Sum of all items:", sum(sample_list))

# 2. Get the largest number from a list.
print("Largest number:", max(sample_list))

# 3. Remove duplicates from a list.
print("List after removing duplicates:", list(set(sample_list)))

def separate_pos_neg(lst):
    positive = [num for num in lst if num >= 0]
    negative = [num for num in lst if num < 0]
    return positive, negative

def filter_even_odd(lst):
    even = [num for num in lst if num % 2 == 0]
    odd = [num for num in lst if num % 2 != 0]
    return even, odd

# 4. Separate positive and negative number from a list.
positive_nums, negative_nums = separate_pos_neg(sample_list)
print("Positive numbers:", positive_nums)
print("Negative numbers:", negative_nums)

# 5. Filter even and odd number from a list.
even_nums, odd_nums = filter_even_odd(sample_list)
print("Even numbers:", even_nums)
print("Odd numbers:", odd_nums)
