# Function to divide two numbers
def divide_numbers(a, b):
    try:
        result = a / b
    except ZeroDivisionError:
        print("Error: Division by zero!")
    else:
        print("Division result:", result)
    finally:
        print("Finally block always executes")

# Test the function
divide_numbers(10, 2)  # No exception
divide_numbers(10, 0)  # Raises ZeroDivisionError
