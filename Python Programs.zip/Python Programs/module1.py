# Function to greet the user
def greet_user(name):
    print("Hello,", name, "!")
