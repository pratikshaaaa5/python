def reverse_string(s):
    return s[::-1]

def count_vowels_consonants(s):
    vowels = 0
    consonants = 0
    for char in s:
        if char.lower() in 'aeiou':
            vowels += 1
        elif char.isalpha():
            consonants += 1
    return vowels, consonants

def count_letters(word):
    return len(word)

def convert_case(s):
    return s.swapcase()

def count_characters(s):
    lower_count = sum(1 for char in s if char.islower())
    upper_count = sum(1 for char in s if char.isupper())
    numeric_count = sum(1 for char in s if char.isnumeric())
    special_count = len(s) - (lower_count + upper_count + numeric_count)
    return lower_count, upper_count, numeric_count, special_count

# Sample string
sample_string = "Hello World! 123"

# 1. Reverse string.
print("Reversed string:", reverse_string(sample_string))

# 2. Count vowels and consonants in a string.
vowels, consonants = count_vowels_consonants(sample_string)
print("Number of vowels:", vowels)
print("Number of consonants:", consonants)

# 3. Count the number of letters in a word.
word = "Hello"
print("Number of letters in the word:", count_letters(word))

# 4. Convert lower letter to upper and upper letter to lower in a string.
print("Converted case:", convert_case(sample_string))

# 5. Count lower, upper, numeric and special characters in a string.
lower, upper, numeric, special = count_characters(sample_string)
print("Number of lower case characters:", lower)
print("Number of upper case characters:", upper)
print("Number of numeric characters:", numeric)
print("Number of special characters:", special)
