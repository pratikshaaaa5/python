# Decorator function
def my_decorator(func):
    def wrapper():
        print("Something is happening before the function is called.")
        func()
        print("Something is happening after the function is called.")
    return wrapper

# Function decorated with the decorator
@my_decorator
def say_hello():
    print("Hello!")

# Generator function
def my_generator(n):
    for i in range(n):
        yield i

# Using the generator
gen = my_generator(5)
print("Generated numbers:")
for num in gen:
    print(num)
